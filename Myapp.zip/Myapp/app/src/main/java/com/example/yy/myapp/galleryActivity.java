package com.example.yy.myapp;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class galleryActivity extends AppCompatActivity {
    private ImageView mimageView2;
    private static final int IMAGE_GALLERY_REQUEST =20 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gallery_activity);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mimageView2 = (ImageView) this.findViewById(R.id.imag0);

        final FloatingActionButton mFab = (FloatingActionButton) findViewById(R.id.fab1);
        FloatingActionButton mGalleryButton = (FloatingActionButton) findViewById(R.id.galleryButton);

        final LinearLayout mGalleryLayout = (LinearLayout) findViewById(R.id.galleryLayout);

        final Animation mShowButton = AnimationUtils.loadAnimation(galleryActivity.this, R.anim.show_button);
        final Animation mHideButton = AnimationUtils.loadAnimation(galleryActivity.this, R.anim.hide_button);
        final Animation mShowLayout = AnimationUtils.loadAnimation(galleryActivity.this, R.anim.show_layout);
        final Animation mHideLayout = AnimationUtils.loadAnimation(galleryActivity.this, R.anim.hide_layout);

        mFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mGalleryLayout.getVisibility() == View.VISIBLE) {

                    mGalleryLayout.setVisibility(View.GONE);
                    mGalleryLayout.startAnimation(mHideLayout);
                    mFab.startAnimation(mHideButton);
                } else {
                    mGalleryLayout.setVisibility(View.VISIBLE);
                    mGalleryLayout.startAnimation(mShowLayout);

                    mFab.startAnimation(mShowButton);
                }
                //   startActivity(new Intent(Intent.ACTION_VIEW));
            }
        });
    }

    private String getPictureName() {
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd_HHmmss");
        String timestamp = sdf.format(new Date());
        return "PlantPlacesImage"+timestamp+".jpg";
    }

    //what happened after i click on gallery floating button
    public void onImageGalleryClicked(View view){

        //invoke image gallery using an implicit intent
        Intent photoePickerIntent=new Intent(Intent.ACTION_PICK);
        //where do we want to find data?
        File pictureDirectory= Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        String pictureDirectoryPath=pictureDirectory.getPath();

        //get uri represintation
        Uri data=Uri.parse(pictureDirectoryPath);
        //set date and type , get all type of image
        photoePickerIntent.setDataAndType(data,"image/*");
        //invoke this activity , and get sth back from it
        startActivityForResult(photoePickerIntent,IMAGE_GALLERY_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode , int resultCode , Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //if we are here , every thing is going successfully
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == IMAGE_GALLERY_REQUEST) {
                //we are hearing back from image gallery

                //the address of image on sd card
                Uri imageUri = data.getData();
                //declare stream to read image data from sd card
                InputStream inputstream;
                //getting input stream , based on uri of image
                try {
                    inputstream = getContentResolver().openInputStream(imageUri);
                    //get bitmap from stream
                    Bitmap image = BitmapFactory.decodeStream(inputstream);
                    //show image to user
                    mimageView2.setImageBitmap(image);

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                    //show message to user indication image is unavailable
                    Toast.makeText(this, "unable to open image", Toast.LENGTH_LONG).show();
                }
            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.super.onCreateOptionsMenu()e
        getMenuInflater().inflate(R.menu.galleryactivity, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_Home) {
            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
        }

        return super.onOptionsItemSelected(item);
    }

}
