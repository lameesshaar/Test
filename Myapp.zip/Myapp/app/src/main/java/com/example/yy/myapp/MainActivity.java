package com.example.yy.myapp;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MainActivity extends AppCompatActivity {

    private static final int CAMERA_REQUEST = 1888;
    private static final int IMAGE_GALLERY_REQUEST =20 ;
    private ImageView mimageView2;
    private CardView imageContainer;
    private int requestCode;
    private int resultCode;
    private Intent data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        imageContainer = (CardView) findViewById(R.id.imageContainer);
        setSupportActionBar(toolbar);

ImageView imageView=(ImageView)findViewById(R.id.myImageView);
        imageView.setImageResource(R.drawable.tomato);
/*
        mimageView2 = (ImageView) this.findViewById(R.id.imag0);

        final FloatingActionButton mFab = (FloatingActionButton) findViewById(R.id.fab1);
        FloatingActionButton mCameraButton = (FloatingActionButton) findViewById(R.id.cameraButton);
        FloatingActionButton mGalleryButton = (FloatingActionButton) findViewById(R.id.galleryButton);

        final LinearLayout mCameraLayout = (LinearLayout) findViewById(R.id.cameraLayout);
        final LinearLayout mGalleryLayout = (LinearLayout) findViewById(R.id.galleryLayout);

        final Animation mShowButton = AnimationUtils.loadAnimation(MainActivity.this, R.anim.show_button);
        final Animation mHideButton = AnimationUtils.loadAnimation(MainActivity.this, R.anim.hide_button);
        final Animation mShowLayout = AnimationUtils.loadAnimation(MainActivity.this, R.anim.show_layout);
        final Animation mHideLayout = AnimationUtils.loadAnimation(MainActivity.this, R.anim.hide_layout);*/


      /*  mFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mCameraLayout.getVisibility() == View.VISIBLE && mGalleryLayout.getVisibility() == View.VISIBLE) {

                    mCameraLayout.setVisibility(View.GONE);
                    mGalleryLayout.setVisibility(View.GONE);
                    mCameraLayout.startAnimation(mHideLayout);
                    mGalleryLayout.startAnimation(mHideLayout);
                    mFab.startAnimation(mHideButton);
                } else {
                    mCameraLayout.setVisibility(View.VISIBLE);
                    mGalleryLayout.setVisibility(View.VISIBLE);
                    mCameraLayout.startAnimation(mShowLayout);
                    mGalleryLayout.startAnimation(mShowLayout);
                    mFab.startAnimation(mShowButton);
                }
                //   startActivity(new Intent(Intent.ACTION_VIEW));
            }
        });*/

       imageContainer.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                //to store image taken by camera
                   File pictureDirectory= Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                   String pictureName=getPictureName();
                   File imageFile=new File(pictureDirectory,pictureName);
                   Uri pictureUri= Uri.fromFile(imageFile);
                   cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT,pictureUri);
                //end of storing process in android device monitor

                   startActivityForResult(cameraIntent, CAMERA_REQUEST);

            }
        });
    }

    private String getPictureName() {
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd_HHmmss");
        String timestamp = sdf.format(new Date());
        return "PlantPlacesImage"+timestamp+".jpg";
    }

    /*

    //what happened after i click on gallery floating button
    public void onImageGalleryClicked(View view){

        //invoke image gallery using an implicit intent
        Intent photoePickerIntent=new Intent(Intent.ACTION_PICK);
        //where do we want to find data?
        File pictureDirectory= Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        String pictureDirectoryPath=pictureDirectory.getPath();

        //get uri represintation
        Uri data=Uri.parse(pictureDirectoryPath);
        //set date and type , get all type of image
        photoePickerIntent.setDataAndType(data,"image/*");
        //invoke this activity , and get sth back from it
        startActivityForResult(photoePickerIntent,IMAGE_GALLERY_REQUEST);
    }*/

    @Override
    public void onActivityResult(int requestCode , int resultCode , Intent data){
        super.onActivityResult(requestCode , resultCode , data);
        if(resultCode==RESULT_OK){
            if (requestCode == CAMERA_REQUEST){
                // Bitmap mphoto = (Bitmap) data.getExtras().get("data");
                // mimageView2.setImageBitmap(mphoto);
            }
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.super.onCreateOptionsMenu()e
        getMenuInflater().inflate(R.menu.mainactivity, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_Home) {
            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
        }

        if (id == R.id.selection) {
            Intent i = new Intent(this, galleryActivity.class);
            startActivity(i);
        }

        return super.onOptionsItemSelected(item);
    }

//end of class mainActivity
}

